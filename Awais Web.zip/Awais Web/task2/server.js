const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(__dirname, 'team.json');

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));


const readData = () => {
  const data = fs.readFileSync(DATA_FILE);
  return JSON.parse(data);
};


const writeData = (data) => {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
};


app.get('/api/team', (req, res) => {
  res.json(readData());
});


app.post('/api/team/members', (req, res) => {
  const data = readData();
  const newMember = {
    id: Date.now(),
    ...req.body
  };
  data.members.push(newMember);
  writeData(data);
  res.status(201).json(newMember);
});


app.put('/api/team/members/:id', (req, res) => {
  const data = readData();
  const id = parseInt(req.params.id);
  const index = data.members.findIndex(m => m.id === id);
  if (index !== -1) {
    data.members[index] = { ...data.members[index], ...req.body };
    writeData(data);
    res.json(data.members[index]);
  } else {
    res.status(404).send('Member not found');
  }
});


app.delete('/api/team/members/:id', (req, res) => {
  const data = readData();
  const id = parseInt(req.params.id);
  data.members = data.members.filter(m => m.id !== id);
  writeData(data);
  res.status(204).send();
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
