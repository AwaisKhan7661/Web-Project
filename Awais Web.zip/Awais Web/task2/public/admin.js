document.addEventListener('DOMContentLoaded', () => {
  const adminList = document.getElementById('admin-team-list');
  const modal = document.getElementById('admin-modal');
  const memberForm = document.getElementById('member-form');
  const addBtn = document.getElementById('add-member-btn');
  const closeModal = document.querySelector('.close-modal');
  const modalTitle = document.getElementById('modal-title');

  let isEditing = false;

  async function fetchTeam() {
    const res = await fetch('/api/team');
    const data = await res.json();
    renderAdminList(data.members);
  }

  function renderAdminList(members) {
    adminList.innerHTML = '';
    members.forEach(member => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
                <td><img src="${member.image}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;"></td>
                <td style="font-weight: 600;">${member.name}</td>
                <td style="color: var(--text-muted);">${member.role}</td>
                <td>
                    <div class="actions">
                        <button class="btn-edit" onclick="editMember(${member.id})"><i class="fas fa-edit"></i></button>
                        <button class="btn-delete" onclick="deleteMember(${member.id})"><i class="fas fa-trash"></i></button>
                    </div>
                </td>
            `;
      adminList.appendChild(tr);
    });
  }

  addBtn.onclick = () => {
    isEditing = false;
    modalTitle.textContent = 'Add New Member';
    memberForm.reset();
    document.getElementById('member-id').value = '';
    openModal();
  };

  function openModal() {
    modal.style.display = 'flex';
    setTimeout(() => modal.classList.add('active'), 10);
  }

  closeModal.onclick = () => {
    modal.classList.remove('active');
    setTimeout(() => modal.style.display = 'none', 300);
  };

  memberForm.onsubmit = async (e) => {
    e.preventDefault();
    const id = document.getElementById('member-id').value;
    const memberData = {
      name: document.getElementById('form-name').value,
      role: document.getElementById('form-role').value,
      image: document.getElementById('form-image').value,
      bio: document.getElementById('form-bio').value,
      social: {
        linkedin: document.getElementById('form-linkedin').value,
        github: document.getElementById('form-github').value
      }
    };

    const url = isEditing ? `/api/team/members/${id}` : '/api/team/members';
    const method = isEditing ? 'PUT' : 'POST';

    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(memberData)
    });

    closeModal.onclick();
    fetchTeam();
  };

  window.editMember = async (id) => {
    const res = await fetch('/api/team');
    const data = await res.json();
    const member = data.members.find(m => m.id === id);

    isEditing = true;
    modalTitle.textContent = 'Edit Member';

    document.getElementById('member-id').value = member.id;
    document.getElementById('form-name').value = member.name;
    document.getElementById('form-role').value = member.role;
    document.getElementById('form-image').value = member.image;
    document.getElementById('form-bio').value = member.bio;
    document.getElementById('form-linkedin').value = member.social.linkedin;
    document.getElementById('form-github').value = member.social.github;

    openModal();
  };

  window.deleteMember = async (id) => {
    if (confirm('Are you sure you want to delete this member?')) {
      await fetch(`/api/team/members/${id}`, { method: 'DELETE' });
      fetchTeam();
    }
  };

  fetchTeam();
});
