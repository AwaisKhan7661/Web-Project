document.addEventListener('DOMContentLoaded', async () => {
  const teamGrid = document.getElementById('team-grid');
  const searchInput = document.getElementById('search-input');
  const roleFilter = document.getElementById('role-filter');


  const companyName = document.getElementById('company-name');
  const companyDesc = document.getElementById('company-description');
  const companyMission = document.getElementById('company-mission');
  const companyVision = document.getElementById('company-vision');

  let allMembers = [];


  async function fetchData() {
    try {
      const response = await fetch('/api/team');
      const data = await response.json();


      companyName.textContent = data.company.name;
      companyDesc.textContent = data.company.description;
      companyMission.textContent = data.company.mission;
      companyVision.textContent = data.company.vision;

      allMembers = data.members;
      renderTeam(allMembers);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }

  function renderTeam(members) {
    teamGrid.innerHTML = '';
    members.forEach(member => {
      const card = document.createElement('div');
      card.className = 'team-card glass';
      card.innerHTML = `
                <div class="member-img-wrapper">
                    <img src="${member.image}" alt="${member.name}">
                </div>
                <div class="member-info">
                    <h3>${member.name}</h3>
                    <span class="member-role">${member.role}</span>
                    <p>${member.bio.substring(0, 100)}...</p>
                    <div class="member-social">
                        <a href="${member.social.linkedin}" target="_blank"><i class="fab fa-linkedin"></i></a>
                        <a href="${member.social.github}" target="_blank"><i class="fab fa-github"></i></a>
                    </div>
                </div>
            `;
      card.addEventListener('click', () => openModal(member));
      teamGrid.appendChild(card);
    });
  }


  const modal = document.getElementById('profile-modal');
  const modalBody = document.getElementById('modal-body');
  const closeModal = document.querySelector('.close-modal');

  function openModal(member) {
    modalBody.innerHTML = `
            <div style="display: flex; gap: 30px; align-items: center; flex-wrap: wrap;">
                <img src="${member.image}" style="width: 200px; border-radius: 20px;">
                <div style="flex: 1; min-width: 250px;">
                    <h2 style="font-size: 2.5rem; margin-bottom: 5px;">${member.name}</h2>
                    <span style="color: var(--primary); font-weight: 700; font-size: 1.2rem;">${member.role}</span>
                    <div style="margin-top: 20px;">
                        <p style="font-size: 1.1rem; line-height: 1.8;">${member.bio}</p>
                    </div>
                    <div class="member-social" style="margin-top: 30px;">
                        <a href="${member.social.linkedin}" style="font-size: 1.5rem;"><i class="fab fa-linkedin"></i></a>
                        <a href="${member.social.github}" style="font-size: 1.5rem;"><i class="fab fa-github"></i></a>
                    </div>
                </div>
            </div>
        `;
    modal.style.display = 'flex';
    setTimeout(() => modal.classList.add('active'), 10);
  }

  closeModal.onclick = () => {
    modal.classList.remove('active');
    setTimeout(() => modal.style.display = 'none', 300);
  };


  function filterMembers() {
    const searchTerm = searchInput.value.toLowerCase();
    const role = roleFilter.value;

    const filtered = allMembers.filter(member => {
      const matchesSearch = member.name.toLowerCase().includes(searchTerm);
      const matchesRole = role === '' || member.role.includes(role);
      return matchesSearch && matchesRole;
    });

    renderTeam(filtered);
  }

  searchInput.addEventListener('input', filterMembers);
  roleFilter.addEventListener('change', filterMembers);

  fetchData();
});
